export enum UserRoles {
  ROLE_ADMIN = "ROLE_ADMIN",
  ROLE_USER = "ROLE_USER"
}
