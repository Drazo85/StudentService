export interface City{
  zipCode: string;
  name: string;
}
