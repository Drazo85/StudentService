export interface Title{
  titleId?: number;
  title: string;
}
