export interface PageRequest {
  pageNo: number;
  pageSize: number;
  sortBy: string;
  sortOrder: string;
  totalItems: number;
  id?: number;
}
