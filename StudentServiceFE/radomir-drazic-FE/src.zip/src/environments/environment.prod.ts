export const environment = {
  production: true,
  serverUrl: 'http://my.server.my'
};
